import logo from "./luxury-car-silhouette-black.jpg";
import "./App.css";

import React, { Component } from "react";
import Cars from "./components/Cars";
import ReactDOM from "react-dom";
//import SockJsClient from "react-stomp";
import { RabbitMqInterface } from "rabbitode";

class App extends Component {
  state = {
    cars: [
      {
        id: "1",
        brand: "Rolls Royce",
        model: "Phantom",
        color: "White",
        location: "Sevilla",
        price: "520000"
      }
    ],
    inputs: {
      brand: "Ferrari",
      model: "",
      location: "",
      color: "",
      price: 0
    },
    amqpMessage: "",
    lastAction: ""
  };

  componentDidMount() {
    this.getAllCars();
    // this.amqpListener();
    this.createAMQPClient();
  }

  createAMQPClient() {
    console.log("Starting AMQP listener...");
    const myConnection = new RabbitMqInterface();
    myConnection.enableDebugging();
    myConnection.setRabbitUri("amqp://localhost");
    //myConnection.setRabbitUri("http://localhost:5672");

    myConnection.sendDirect({
      exchangeName: "car-dealer-exchange",
      routingKey: "demo.routing.key",
      content: {
        message: "Message from client test"
      }
    });

    const handleConsume = channel => msg => {
      console.log(myConnection.decodeToString(msg));
      channel.ack(msg);
    };

    const topics = ["demo.*.*"];
    myConnection.startTopicConsumer(
      {
        exchangeName: "car-dealer-exchange",
        exchangeType: "topic",
        consumerCallback: handleConsume
      },
      topics
    );
  }

  getAllCars() {
    console.log("get all cars");
    fetch("http://localhost:8080/api/v1/cars", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    })
      .then(res => res.json())
      .then(data => {
        this.setState({ cars: data });
      })
      .catch(console.log);
  }

  handleChange(e) {
    this.setState({
      inputs: {
        ...this.state.inputs,
        [e.target.name]: e.target.value
      }
    });
  }

  validateFields() {
    const fields = this.state.inputs;
    return (
      fields.brand !== null &&
      fields.brand !== "" &&
      fields.color !== null &&
      fields.color !== "" &&
      fields.location !== null &&
      fields.location !== "" &&
      fields.model !== null &&
      fields.model !== "" &&
      fields.price !== null &&
      fields.price !== "" &&
      !isNaN(fields.price) &&
      fields.price > 0
    );
  }

  handleSubmit(e) {
    console.log("submit");
    e.preventDefault();
    let validFields = this.validateFields();
    if (validFields) {
      let car = {
        brand: this.state.inputs.brand,
        model: this.state.inputs.model,
        location: this.state.inputs.location,
        color: this.state.inputs.color,
        price: this.state.inputs.price
      };
      let action = "Added " + car.brand + " " + car.model;
      fetch("http://localhost:8080/api/v1/new", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify(car)
      })
        .then(res => res.json())
        .then(this.getAllCars())
        .then(
          this.setState({
            lastAction: action
          })
        )
        .catch(console.log);
    }
  }

  handleDelete(id) {
    console.log("delete");
    if (id && !isNaN(id) && window.confirm("Delete car?")) {
      const urlCarDelete = "http://localhost:8080/api/v1/cars/" + id;
      let action = "Deleted car " + id;
      fetch(urlCarDelete, {
        method: "DELETE"
      })
        .then(this.getAllCars())
        .then(
          this.setState({
            lastAction: action
          })
        )
        .catch(console.log);
    }
  }

  render() {
    console.log("render");
    const that = this;
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="restrict-size" alt="logo" />
          <h1>LUXURY CARS DEALER INC.</h1>
          <p>Home of the least imaginative dealer name</p>
        </header>
        {this.state.amqpMessage ? (
          <AmqpMessageToast message={this.state.amqpMessage} />
        ) : null}
        <div className="container-fluid App-body pb-5">
          <div className="row">
            <div className="col-4 pb-3">
              <form onSubmit={e => this.handleSubmit.call(this, e)}>
                <div className="form-group">
                  <label htmlFor="brand">Brand</label>
                  <select
                    className="form-control"
                    id="brand"
                    name="brand"
                    value={this.state.inputs.brand}
                    onChange={e => this.handleChange.call(this, e)}
                  >
                    <option value="Ferrari">Ferrari</option>
                    <option value="Lamborghini">Lamborghini</option>
                    <option value="Rolls Royce">Rolls Royce</option>
                    <option value="Bentley">Bentley</option>
                    <option value="Porsche">Porsche</option>
                    <option value="Bugatti">Bugatti</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="form-group">
                  <label htmlFor="model">Model</label>
                  <input
                    type="text"
                    name="model"
                    className={
                      this.state.inputs.model === ""
                        ? "form-control errorInput"
                        : "form-control"
                    }
                    id="model"
                    placeholder="Model"
                    value={this.state.inputs.model}
                    onChange={e => this.handleChange.call(this, e)}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="color">Color</label>
                  <input
                    type="text"
                    className={
                      this.state.inputs.color === ""
                        ? "form-control errorInput"
                        : "form-control"
                    }
                    id="color"
                    placeholder="Color"
                    name="color"
                    value={this.state.inputs.color}
                    onChange={e => this.handleChange.call(this, e)}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="price">Price</label>
                  <input
                    type="text"
                    className={
                      this.state.inputs.price === "" ||
                      this.state.inputs.price === 0 ||
                      isNaN(this.state.inputs.price)
                        ? "form-control errorInput"
                        : "form-control"
                    }
                    id="price"
                    placeholder="Price"
                    name="price"
                    value={this.state.inputs.price}
                    onChange={e => this.handleChange.call(this, e)}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="location">Location</label>
                  <input
                    type="text"
                    className={
                      this.state.inputs.location === ""
                        ? "form-control errorInput"
                        : "form-control"
                    }
                    id="location"
                    placeholder="Location"
                    name="location"
                    value={this.state.inputs.location}
                    onChange={e => this.handleChange.call(this, e)}
                  />
                </div>
                <button type="submit" className="btn btn-primary">
                  New
                </button>
              </form>
            </div>
            <div className="col-8">
              <Cars
                cars={this.state.cars}
                onDeleteFunction={e => that.handleDelete.call(that, e)}
              />
            </div>
          </div>
        </div>
        <p className="pt-2">
          Developed by Ignacio Santos. Check it out in{" "}
          <a href="https://github.com/Nacho1980/fexco-multiprotocol-api-demo">
            Github
          </a>
        </p>
      </div>
    );
  }
}

export default App;

//const wrapper = document.getElementById("container");
//wrapper ? ReactDOM.render(<App />, wrapper) : false;
