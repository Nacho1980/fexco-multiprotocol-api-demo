package com.demo.multiprotocol.server.api.amqp;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * A very simple listener that can be used for testing purposes since in the
 * application the listener will be running in Node
 * 
 * @author Ignacio Santos
 *
 */
@Component
public class Listener {
	@RabbitListener(queues = "${amqp.queue.test}")
	public void listen(String message) {
		System.out.println("Received a new message: " + message);
	}
}
