import http from "k6/http";

/**
 * Stress tests for the REST API
 * @author Ignacio Santos
 */
export default function() {
  // GET car listing
  http.get("http://localhost:8080/api/v1/cars");

  // POST for the submission of a new car
  const urlPost = "http://localhost:8080/api/v1/new";
  const payloadPost = JSON.stringify({
    brand: "Lamborghini",
    model: "Aventador",
    location: "NY",
    color: "Yellow",
    price: 339000
  });
  const paramsPost = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    }
  };
  http.post(urlPost, payloadPost, paramsPost);

  // DELETE a car (given the id)
  const id = 1;
  const urlDelete = "http://localhost:8080/api/v1/cars/" + id;
  http.del(urlDelete, payloadPost, paramsPost);
}
