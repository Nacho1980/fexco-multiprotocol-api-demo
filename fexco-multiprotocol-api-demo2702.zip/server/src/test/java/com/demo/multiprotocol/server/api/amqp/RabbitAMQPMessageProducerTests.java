package com.demo.multiprotocol.server.api.amqp;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;
import org.springframework.amqp.AmqpConnectException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RabbitAMQPMessageProducerTests {
	@Autowired
	private Publisher publisher;
//	@Autowired
//	private Listener listener;

	/**
	 * In this test we actually send a message which can be received in the Node
	 * listener. The listener has also been implemented in the java side but it will
	 * intercept all communications between our publisher and the node listener.
	 * 
	 * Another possibility is to have a exchange that redirects the message to 2
	 * queues: in one of them we'd have the Java listener and in the other the Node
	 * listener.
	 * 
	 * @throws Exception
	 */
	@Test
	public void test() throws Exception {
		try {
			publisher.sendMessage("test");
			// No need to explicitly call the listener that will consume the message as long
			// as it is in the same queue
		} catch (AmqpConnectException e) {
			fail("AMQP test failed", e);
		}
	}
}
