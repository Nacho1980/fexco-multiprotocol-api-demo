package com.demo.multiprotocol.server.api.amqp;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class Listener {
	@RabbitListener(queues = "${amqp.queue.test}")
	public void listen(String message) {
		System.out.println("Received a new message: " + message);
	}
}
